<?php

namespace App\Http\Controllers;

use App\Models\TransactionHeader;
use App\Models\Cart;
use App\Models\TransactionDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransactionHeaderController extends Controller
{
    public function index()
    {
        return view('checkout');
    }

    public function store(Request $request)
    {
        $validateData = $request->validate([
            'full_name' => 'required|min:5',
            'phone_number' => 'required|numeric|digits:12',
            'address' => 'required|min:5',
            'city' => 'required|min:5',
            'cardholder_name' => 'required|min:3',
            'card_number' => 'required|numeric|digits:16',
            'country' => 'required',
            'zip_code' => 'required|numeric',
        ]);

        $user_id=auth()->user()->id;

        $data = [
            'user_id' => $user_id,
            'full_name' => $validateData['full_name'],
            'phone_number' => $validateData['phone_number'],
            'country' => $validateData['country'],
            'city' => $validateData['city'],
            'cardholder_name' => $validateData['cardholder_name'],
            'card_number' => $validateData['card_number'],
            'address' => $validateData['address'],
            'zip_code' => $validateData['zip_code'],
        ];

        $checkout = TransactionHeader::make($data);

        $checkout->save();

        $carts = Cart::where('user_id',$user_id)->get();
        foreach ($carts as $cart ) {
            TransactionDetail::create([
                'food_id'=>$cart->food_id,
                'header_id'=>$checkout->id,
                'qty'=>$cart->qty
            ]);
        }

        Cart::where('user_id',$user_id)->delete();

        $message = 'Checkout Successful';

        return redirect()->route('home')->with('success', $message);
    }
}
