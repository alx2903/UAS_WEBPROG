<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('#success-message').fadeOut('slow');
            }, 2000);

            setTimeout(function() {
                $('#error-message').fadeOut('slow');
            }, 2000);
        });
    </script>

        <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body style="background-image: url(/assets/download.jpg); width: 100%">

    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black">
        <div class="container-fluid">

            
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">XiAO DiNG DoNG</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role == 'user'): ?>
                            <a class="nav-link active" href="<?php echo e(route('managefood.search')); ?>">Search Food</a>
                            <a class="nav-link active" href="<?php echo e(route('user.cart')); ?>">Cart</a>
                        <?php else: ?>
                            <a class="nav-link active" href="<?php echo e(route('food.add')); ?>">Add New Food</a>
                            <a class="nav-link active" href="<?php echo e(route('managefood.index')); ?>">Manage Food</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav" >
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role == 'user'): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-warning d-flex align-items-center gap-3" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Welcome, <?php echo e(auth()->user()->name); ?>

                                    <div style="border: 1px white solid; width: 30px;height: 30px; border-radius: 20px;">
                                        <img id="profilePic" src="<?php echo e(asset('user/'.auth()->user()->berkas)); ?>" alt="NoProfilePic" width="100%" height="100%" style="border-radius: 20px;">
                                    </div>
                                </a>

                                <ul class="dropdown-menu bg-dark" aria-labelledby="navbarScrollingDropdown">
                                    <li><a class="dropdown-item text-warning bg-dark" href="/profile">Profile</a></li>
                                    <li><a class="dropdown-item text-warning bg-dark" href="/history">Transaction History</a></li>
                                    <li><hr style="color: white" class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-warning bg-dark" href="<?php echo e(route('logout')); ?>">Sign Out</a></li>
                                </ul>
                            </li>
                            <script>
                                document.getElementById('profilePic').onerror = function() {
                                  this.src = '<?php echo e(asset('user/default.webp')); ?>';
                                  this.alt = 'FavIcon';
                                };
                              </script>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Welcome, <?php echo e(auth()->user()->name); ?>

                                </a>
                                <ul class="dropdown-menu bg-dark" aria-labelledby="navbarScrollingDropdown">
                                    <li><a class="dropdown-item text-warning bg-dark" href="/profile">Profile</a></li>
                                    <li><hr  style="color: white" class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-warning bg-dark" href="<?php echo e(route('logout')); ?>">Sign Out</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item me-3">
                                <a class="nav-link active " href="<?php echo e(route('login')); ?>">Login</a>
                            </li>
                            <li class="nav-item me-3">
                                <a class="nav-link active " href="<?php echo e(route('register')); ?>">Register</a>
                            </li>
                        </ul>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>


<div class="d-flex flex-column align-items-center">
    
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php if($errors->any()): ?>
<div id="error-message" class="alert alert-danger position-fixed top-0 start-50 translate-middle-x">
    <ul class="list-unstyled">
        <li><?php echo e($errors->first()); ?></li>
    </ul>
</div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div id="success-message" class="alert alert-success position-fixed top-0 start-50 translate-middle-x">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

</body>
</html>
<?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\temp_project - Copy\temp_project - Copy\resources\views////components/master.blade.php ENDPATH**/ ?>