<?php $__env->startSection('title','XIAO DING DONG | CART'); ?>

<?php $__env->startSection('content'); ?>

<style>
    th,tr,td{
        border: 1px solid black;
    }
    td {
      padding: 8px;
      text-align: center;
      vertical-align: middle;
    }
    .circle-button {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 1px solid #ccc;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        background-color: grey;
    }
</style>

<div class="d-flex flex-column justify-center text-warning" style="width: 80%; gap: 2rem; margin-top: 2rem;">
    <h1> 你的购物车 | CART</h1>


    <?php if($count>0): ?>
        <table class="table table-bordered" style="text-align: center; width: 100%">
            <thead style="background-color: black; width: 100%" class="text-warning">
                <tr>
                    <th>Food</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            
            <tbody  style="color: whitesmoke; background-color: rgb(90, 89, 89)" >
                <?php
                    $total=0;
                ?>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex justify-content-center align-items-center" style="height: 100%"><?php echo e($cart->food->food_name); ?></div>
                        </td>
                        <td>Rp. <?php echo e($cart->food->price); ?></td>
                        <td >
                            <div class="d-flex justify-content-center align-items-center">
                                <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="-" name="operator">
                                    <input type="hidden" value="<?php echo e($cart->food_id); ?>" name="food_id">
                                    <button type="submit" class="circle-button" style="margin-right: 8px;">
                                        -
                                    </button>
                                </form>
                                <?php echo e($cart->qty); ?>

                                <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="+" name="operator">
                                    <input type="hidden" value="<?php echo e($cart->food_id); ?>" name="food_id">
                                    <button type="submit" class="circle-button" style="margin-left: 8px;">
                                        +
                                    </button>
                                </form>
                            </div>

                        </td>
                        <td>Rp. <?php echo e($cart->qty*$cart->food->price); ?></td>
                        <td  class="d-flex justify-content-center align-items-center">
                            <form action="<?php echo e(route('cart.destroy', $cart)); ?>" method="POST" style="margin: 0;padding: 0;"  class="d-flex justify-content-center align-items-center">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="hidden" value="<?php echo e($cart->food_id); ?>" name="food_id">
                                <button type="submit" class="btn btn-warning mt-2 text-warning" style="text-align: center; background-color: black;">
                                    <i class="bi bi-trash" style="border:azure;"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php
                        $total+=$cart->qty*$cart->food->price;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div style="align-self: flex-end; color: white; margin: 5px 10px 0 0" class="d-flex flex-column ">
            <h3>Total Price: $<?php echo e($total); ?></h3>
            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-dark" style="border-radius: 10px; color: whitesmoke; text-decoration: none; padding: 5px 10px;">Proceed To Checkout</a>
        </div>
    <?php else: ?>
        <div style="background-color: black; border-radius: 20px; display: flex; justify-content: center;align-items: center; flex-direction: column" >
            <h1 class="text-warning">Your cart is empty... </h1>
            <p style="color: whitesmoke">Looks like your cart is on a diet! Don't worry our delicious dishes are just a few clicks away. Start filling up your cart and let the feast begin!</p>
        </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\temp_project - Copy\temp_project - Copy\resources\views/cart.blade.php ENDPATH**/ ?>