<?php $__env->startSection('title','XIAO DING DONG | HOME'); ?>

<?php $__env->startSection('content'); ?>
test

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\project_lab\resources\views/welcome.blade.php ENDPATH**/ ?>