<?php $__env->startSection('title','XIAO DING DONG | DETAILS'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column justify-center text-warning" style="width: 80%; gap: 2rem; margin-top: 2rem;">
    <h1 style="text-align: center"> 食物细节 | Food Detail </h1>

    
    <?php if(!empty($food[0])): ?>
        <div style="text-align: center; background-color: rgb(35, 35, 35);font-size: 25px;color: whitesmoke">Food is not available</div>
    <?php else: ?>
        <div style="background-color: black;height: 500px; padding:15px; border-radius: 20px; gap:20px;" class="d-flex">
            <div style="height: 100%; width: 45%;">
                <img src="<?php echo e(asset('images/'.$food->berkas)); ?>" alt="" style="height: 100%; width: 100%">
            </div>
            <div style="gap: 10px; width: 50%" class="d-flex flex-column">
                <h4><?php echo e($food->food_name); ?></h4>
                <div>
                    <h5>Food Type</h5>
                    <p style="color: whitesmoke"><?php echo e($food->food_cat); ?></p>
                </div>
                <div>
                    <h5>Food Price</h5>
                    <p style="color: whitesmoke"><?php echo e($food->price); ?></p>
                </div>
                <div>
                    <h5>Brief Description</h5>
                    <p style="color: whitesmoke"><?php echo e($food->food_desc); ?></p>
                </div>
                <div style="max-width: 100%">
                    <h5>About This Food</h5>
                    <p style="color: whitesmoke"><?php echo e($food->desc); ?></p>
                </div>
                <?php if(Auth::check() && auth()->user()->role == 'user'): ?>
                    <form method="POST" action="<?php echo e(route('cart.add',$food->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($food->id); ?>" name="id">
                        <button type="submit" name="addToCart" class="btn bg-dark text-warning" >Add To Cart</button>
                    </form>
                <?php endif; ?>
                

            </div>
        </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('./components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\temp_project - Copy\temp_project - Copy\resources\views/foodDetail.blade.php ENDPATH**/ ?>