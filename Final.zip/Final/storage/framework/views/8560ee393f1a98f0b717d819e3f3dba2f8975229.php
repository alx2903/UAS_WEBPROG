<?php $__env->startSection('title','XIAO DING DONG | REGISTER'); ?>

<?php $__env->startSection('content'); ?>
    <div style="display:flex;height: 100vh; width:100%;">
        <div style="display: flex; width:60%; height: 100%">
            <img src="<?php echo e(asset('./assets/login_register.jpg')); ?>" alt="" height="100%" width="100%" >
        </div>
        <div style="display:flex; justify-content: center; align-items: center; background-color: rgb(11, 11, 11); height:100%; width:40%;">

            <form class="text-white" action="<?php echo e(route('register.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mb-3" style="text-align: center">
                    <h2>Register</h2>
                </div>
                
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-form-label">Email Address</label>
                    <div class="col-sm-12">
                        <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Has to end with '@gmail.com'">
                    </div>
                </div>

                
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-form-label">Username</label>
                    <div class="col-sm-12">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Minimum 5 characters, Maximum 50 characters">
                    </div>
                </div>

                
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-form-label">Password</label>
                    <div class="col-sm-12">
                        <input type="password" class="form-control" id="inputPassword3" name="password" placeholder="Minimum 5 characters, Maximum 255 characters">
                    </div>
                </div>

                
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-form-label">Confirm Password</label>
                    <div class="col-sm-12">
                        <input type="password" class="form-control" id="inputPassword3" name="confirm_password" placeholder="Has to be the same with Password Field">
                    </div>
                </div>

                
                <div class="row mb-3">
                    <button type="submit" class="btn btn-primary col-sm-11 bg-dark" style="margin-left: 15px">Register</button>
                </div>
                <div class="row mb-3" style="text-align: center">
                    <div>
                        <span>Already have an account?</span>
                        <a href="<?php echo e(route('login')); ?>" style="text-decoration: none; color: yellow">Log in</a>
                    </div>
                </div>
            </form>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\mario_project_lab\resources\views/register.blade.php ENDPATH**/ ?>