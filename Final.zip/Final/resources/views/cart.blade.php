@extends('../components/master')

@section('title','XIAO DING DONG | CART')

@section('content')

<style>
    th,tr,td{
        border: 1px solid black;
    }
    td {
      padding: 8px;
      text-align: center;
      vertical-align: middle;
    }
    .circle-button {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 1px solid #ccc;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        background-color: grey;
    }
</style>

<div class="d-flex flex-column justify-center text-warning" style="width: 80%; gap: 2rem; margin-top: 2rem;">
    <h1> 你的购物车 | CART</h1>


    @if ($count>0)
        <table class="table table-bordered" style="text-align: center; width: 100%">
            <thead style="background-color: black; width: 100%" class="text-warning">
                <tr>
                    <th>Food</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            {{-- style="background-color: gray" --}}
            <tbody  style="color: whitesmoke; background-color: rgb(90, 89, 89)" >
                @php
                    $total=0;
                @endphp
                @foreach ($carts as $cart)
                    <tr>
                        <td>
                            <div class="d-flex justify-content-center align-items-center" style="height: 100%">{{$cart->food->food_name}}</div>
                        </td>
                        <td>Rp. {{$cart->food->price}}</td>
                        <td >
                            <div class="d-flex justify-content-center align-items-center">
                                <form action="{{ route('cart.update') }}" method="POST">
                                    @csrf
                                    <input type="hidden" value="-" name="operator">
                                    <input type="hidden" value="{{ $cart->food_id }}" name="food_id">
                                    <button type="submit" class="circle-button" style="margin-right: 8px;">
                                        -
                                    </button>
                                </form>
                                {{$cart->qty}}
                                <form action="{{ route('cart.update') }}" method="POST">
                                    @csrf
                                    <input type="hidden" value="+" name="operator">
                                    <input type="hidden" value="{{ $cart->food_id }}" name="food_id">
                                    <button type="submit" class="circle-button" style="margin-left: 8px;">
                                        +
                                    </button>
                                </form>
                            </div>

                        </td>
                        <td>Rp. {{$cart->qty*$cart->food->price}}</td>
                        <td  class="d-flex justify-content-center align-items-center">
                            <form action="{{ route('cart.destroy', $cart) }}" method="POST" style="margin: 0;padding: 0;"  class="d-flex justify-content-center align-items-center">
                                @csrf
                                @method('DELETE')
                                <input type="hidden" value="{{ $cart->food_id }}" name="food_id">
                                <button type="submit" class="btn btn-warning mt-2 text-warning" style="text-align: center; background-color: black;">
                                    <i class="bi bi-trash" style="border:azure;"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    @php
                        $total+=$cart->qty*$cart->food->price;
                    @endphp
                @endforeach
            </tbody>
        </table>
        <div style="align-self: flex-end; color: white; margin: 5px 10px 0 0" class="d-flex flex-column ">
            <h3>Total Price: ${{$total}}</h3>
            <a href="{{ route('checkout') }}" class="btn btn-dark" style="border-radius: 10px; color: whitesmoke; text-decoration: none; padding: 5px 10px;">Proceed To Checkout</a>
        </div>
    @else
        <div style="background-color: black; border-radius: 20px; display: flex; justify-content: center;align-items: center; flex-direction: column" >
            <h1 class="text-warning">Your cart is empty... </h1>
            <p style="color: whitesmoke">Looks like your cart is on a diet! Don't worry our delicious dishes are just a few clicks away. Start filling up your cart and let the feast begin!</p>
        </div>
    @endif

</div>

@endsection
