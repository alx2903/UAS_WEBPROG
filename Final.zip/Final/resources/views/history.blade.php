@extends('../components/master')

@section('title', 'XIAO DING DONG | HOME')

@section('content')
<style>
    tbody {
        background-color: lightslategrey;
        color: azure;
        text-align: center;
    }

    thead {
        background-color: black;
        color: gold;
        text-align: center;
    }
</style>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="py-4">
                <h2 style="color: gold; font-weight: bold;">交易记录 | Transaction History</h2>
            </div>

            @if($transactions_details->isNotEmpty())
            <div class="container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Purchase Date</th>
                            <th>Food Name</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        $currentTransactionId = null;
                        $totalTransactionPrice = 0;
                        @endphp

                        @foreach ($transactions_details as $transaction)
                        @if ($transaction->transactionHeader->id !== $currentTransactionId)
                            @if ($currentTransactionId !== null)
                                <tr class="bg-dark">
                                    <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                                    <td>${{ $totalTransactionPrice }}</td>
                                </tr>
                            @endif 

                            @php
                                $currentTransactionId = $transaction->transactionHeader->id;
                                $totalTransactionPrice = 0;
                            @endphp
                        @endif

                        <tr class="bg-dark">
                            <td>TR{{ $transaction->transactionHeader->id }}</td>
                            <td>{{ $transaction->transactionHeader->created_at }}</td>
                            <td>{{ $transaction->food->food_name }} [x{{ $transaction->qty }}]</td>
                            <td>${{ $transaction->food->price * $transaction->qty }}</td>
                        </tr>

                        @php
                        $totalTransactionPrice += $transaction->food->price * $transaction->qty;
                        @endphp
                        @endforeach

                        @if ($currentTransactionId !== null)
                        <tr class="bg-dark">
                            <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                            <td>${{ $totalTransactionPrice }}</td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
            @else
            <div class="text-center" style="background-color: black;">
                <h3 style="color: gold; font-weight: bold">There are no transactions yet...</h3>
                <h5 style="color: azure;">Poof! Transaction history gone. Time to make delicious memories all over
                    again. Let's fill this blank page with savory stories and culinary adventures. Bon appétit!</h5>
            </div>
            @endif
        </div>
    </div>
</div>

@endsection
